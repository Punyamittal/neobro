const iframe = document.getElementById('browser-frame');
const urlInput = document.getElementById('url');

urlInput.addEventListener('keypress', function(e) {
  if (e.key === 'Enter') {
    let url = urlInput.value;
    if (!url.startsWith('http')) {
      url = 'https://' + url;
    }
    iframe.src = url;
  }
});

function goBack() {
  iframe.contentWindow.history.back();
}

function goForward() {
  iframe.contentWindow.history.forward();
}

function refresh() {
  iframe.contentWindow.location.reload();
}

function exit() {
  iframe.src = 'about:blank'; // can't actually close tab from here
}
